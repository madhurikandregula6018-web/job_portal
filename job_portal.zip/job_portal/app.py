from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    # Users table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        password TEXT,
        role TEXT
    )
    """)

    # Jobs table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS jobs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        salary TEXT,
        location TEXT,
        company TEXT
    )
    """)

    # Applications table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS applications(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT,
        job_id INTEGER
    )
    """)

    conn.commit()
    conn.close()

init_db()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        role = request.form["role"]

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO users(name, email, password, role) VALUES (?, ?, ?, ?)",
            (name, email, password, role)
        )

        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM users WHERE email=? AND password=?",
            (email, password)
        )

        user = cursor.fetchone()
        conn.close()

        if user:
            return redirect("/jobs")
        else:
            return "Invalid Email or Password!"

    return render_template("login.html")


@app.route("/jobs")
def jobs():

    search = request.args.get("search")

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    if search:
        cursor.execute("""
        SELECT * FROM jobs
        WHERE title LIKE ?
        OR company LIKE ?
        OR location LIKE ?
        """, (f"%{search}%", f"%{search}%", f"%{search}%"))
    else:
        cursor.execute("SELECT * FROM jobs")

    jobs = cursor.fetchall()

    conn.close()

    return render_template("jobs.html", jobs=jobs)

@app.route("/post")
def post():
    return render_template("post_job.html")


@app.route("/add_job", methods=["POST"])
def add_job():

    title = request.form["title"]
    company = request.form["company"]
    location = request.form["location"]
    salary = request.form["salary"]
    description = request.form["description"]

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO jobs(title,description,salary,location,company)
    VALUES(?,?,?,?,?)
    """,(title,description,salary,location,company))

    conn.commit()
    conn.close()

    return redirect("/jobs")
@app.route("/apply/<int:job_id>")
def apply(job_id):

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    # Temporary user email
    user_email = "demo@gmail.com"

    cursor.execute(
        "INSERT INTO applications(user_email, job_id) VALUES(?, ?)",
        (user_email, job_id)
    )

    conn.commit()
    conn.close()

    return "Application Submitted Successfully!"

@app.route("/delete/<int:id>")
def delete(id):

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("DELETE FROM jobs WHERE id=?", (id,))

    conn.commit()
    conn.close()

    return redirect("/jobs")

if __name__ == "__main__":
    app.run(debug=True)