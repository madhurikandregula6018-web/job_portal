Job Portal Web Application

Project Description

This project is a Job Portal Web Application developed using Python Flask and SQLite. It allows users to register, log in, post jobs, view available jobs, and apply for jobs.

Technologies Used

- Python
- Flask
- SQLite
- HTML
- CSS
- Bootstrap

Features

- User Registration
- User Login
- Job Posting
- View Job Listings
- Apply for Jobs
- SQLite Database

How to Run

1. Install Flask:
   pip install flask

2. Run the application:
   python app.py

3. Open your browser and visit:
   http://127.0.0.1:5000/

Author

Madhuri Kandregula
Python Developer Internship Final Project